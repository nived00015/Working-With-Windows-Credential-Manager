import keyring

# +
def get_credential(service_name):
    c = keyring.get_credential(service_name,None)
    d1 = dict()
    d1["username"]=c.username
    d1["password"]=c.password
    return d1

def set_credential(service_name,username,password):
    keyring.set_password(service_name,username,password)
    
    return  True
    
    
# -





